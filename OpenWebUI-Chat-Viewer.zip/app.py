from flask import Flask, jsonify, render_template
import sqlite3
import json
import os

app = Flask(__name__)

# Path to your database file - update this to your actual path
DB_PATH = 'webui_backup_20250918_102142.db'

def get_db_connection():
    """Create a database connection."""
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row  # This enables column access by name
    return conn

@app.route('/')
def index():
    """Serve the main HTML page."""
    return render_template('index.html')

@app.route('/api/chats', methods=['GET'])
def get_chats():
    """Get all chat sessions."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Query to get all chats with their basic info
        cursor.execute('''
            SELECT id, title, created_at, updated_at 
            FROM chat 
            ORDER BY updated_at DESC
        ''')
        
        chats = []
        for row in cursor.fetchall():
            chats.append({
                'id': row['id'],
                'title': row['title'] if row['title'] else 'Untitled Chat',
                'created_at': row['created_at'],
                'updated_at': row['updated_at']
            })
        
        conn.close()
        return jsonify(chats)
    
    except Exception as e:
        print(f"Error in get_chats: {str(e)}")
        return jsonify({'error': str(e)}), 500

@app.route('/api/chats/<chat_id>', methods=['GET'])
def get_chat_messages(chat_id):
    """Get messages for a specific chat."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        # Query to get the chat data (which contains the messages in JSON format)
        cursor.execute('''
            SELECT chat, title 
            FROM chat 
            WHERE id = ?
        ''', (chat_id,))
        
        row = cursor.fetchone()
        conn.close()
        
        if row is None:
            return jsonify({'error': 'Chat not found'}), 404
        
        # The 'chat' column contains JSON data with the message history
        chat_data = row['chat']
        
        # Parse the JSON data
        if chat_data:
            try:
                # The chat_data is stored as a JSON string
                messages_data = json.loads(chat_data)
                
                # Extract messages - the structure typically has messages in a 'messages' key
                # or sometimes directly as an object with message properties
                if isinstance(messages_data, dict):
                    # Check if there's a 'messages' key
                    if 'messages' in messages_data:
                        messages = messages_data['messages']
                    # Some formats store in 'history'
                    elif 'history' in messages_data:
                        messages = messages_data['history']['messages'] if isinstance(messages_data['history'], dict) else messages_data['history']
                    else:
                        # If no specific key, the whole object might be the messages structure
                        messages = messages_data
                elif isinstance(messages_data, list):
                    # If it's already a list, use it directly
                    messages = messages_data
                else:
                    messages = []
                
                return jsonify({
                    'title': row['title'] if row['title'] else 'Untitled Chat',
                    'messages': messages,
                    'raw_structure': list(messages_data.keys()) if isinstance(messages_data, dict) else 'list'
                })
            
            except json.JSONDecodeError as e:
                print(f"JSON decode error: {str(e)}")
                return jsonify({'error': f'Failed to parse chat data: {str(e)}'}), 500
        else:
            return jsonify({
                'title': row['title'] if row['title'] else 'Untitled Chat',
                'messages': []
            })
    
    except Exception as e:
        print(f"Error in get_chat_messages: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({'error': str(e)}), 500

@app.route('/api/debug/chat/<chat_id>', methods=['GET'])
def debug_chat_structure(chat_id):
    """Debug endpoint to see the raw structure of a chat."""
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM chat WHERE id = ?', (chat_id,))
        row = cursor.fetchone()
        conn.close()
        
        if row is None:
            return jsonify({'error': 'Chat not found'}), 404
        
        # Get all column names and values
        result = dict(row)
        
        # Try to parse the chat JSON for inspection
        if result.get('chat'):
            try:
                chat_json = json.loads(result['chat'])
                result['chat_parsed'] = chat_json
                result['chat_keys'] = list(chat_json.keys()) if isinstance(chat_json, dict) else 'not_dict'
            except:
                result['chat_parsed'] = 'Failed to parse'
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    # Check if database exists
    if not os.path.exists(DB_PATH):
        print(f"WARNING: Database file '{DB_PATH}' not found!")
        print(f"Please update DB_PATH in app.py to point to your database file.")
    
    app.run(host='0.0.0.0', port=5000, debug=True)
